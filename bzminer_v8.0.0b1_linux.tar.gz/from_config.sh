#!/bin/sh
./bzminer -c config.txt