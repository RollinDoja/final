#!/bin/sh

# replace 0000 with your address

# mine to extremehash
./bzminer -a kaspa -w 0000 -p node+tcp://127.0.0.1:16110