#!/bin/sh

# eth + alph
./bzminer -a ethash -w 000000 -p stratum+tcp://us1.ethermine.org:4444 --a2 alph --w2 000000 --p2 stratum+tcp://eu.metapool.tech:20032

# eth + rvn
#./bzminer -a ethash -w 000000 -p stratum+tcp://us1.ethermine.org:4444 --a2 kawpow --w2 000000 --p2 stratum+ssl://stratum-ravencoin.flypool.org:3443

# eth + ol
#./bzminer -a ethash -w 000000 -p stratum+tcp://us1.ethermine.org:4444 --a2 olhash --w2 000000 --p2 ethproxy+ssl://us.extremehash.net:3443
